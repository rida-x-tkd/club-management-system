# Design System Document: Zen Kinetic Strategy
**Client:** Association ABTAL Boukaissi de Taekwondo (A.A.B.T)
**Version:** 1.0
**Director’s Note:** This system is designed to transcend the "utility" of a standard dashboard. We are creating a digital dojo—a space that embodies the discipline, precision, and fluidity of Taekwondo. Through "Zen Kinetic" aesthetics, we prioritize breathing room, technical typography, and tactile feedback.

---

## 1. Overview & Creative North Star
### The Creative North Star: "The Ethereal Dojo"
The design system is anchored by the concept of "The Ethereal Dojo." Much like a premium training hall, the interface must feel expansive and orderly, yet capable of sudden, high-energy movement. We break the traditional "admin template" look by utilizing intentional asymmetry, overlapping glass layers, and a typography scale that favors editorial impact over dense data grids. 

We avoid the "boxed-in" feeling of traditional software. Instead, elements float, breathe, and react with a kinetic energy that mirrors the sport itself.

---

## 2. Color & Atmospheric Tones
The palette is a sophisticated blend of technical cool-tones and high-energy neon highlights.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders for sectioning or containment. Boundaries must be defined through background color shifts. Use `surface_container_low` sections sitting on a `surface` background. If an element needs to stand out, it should do so through elevation or tone, never a stroke.

### Surface Hierarchy & Nesting
To create a "High-End Editorial" feel, we treat the UI as a series of physical layers:
*   **Base:** `background` (#f5f7f9) - The canvas.
*   **Sectioning:** `surface_container_low` (#eef1f3) - For large layout blocks.
*   **Interactive Layers:** `surface_container_lowest` (#ffffff) - For cards and primary focus areas.
*   **Depth Stacking:** A `surface_container_lowest` card should sit inside a `surface_container_low` section to create natural, soft-edge separation.

### The "Glass & Gradient" Rule
To achieve the "Zen Kinetic" feel, use Glassmorphism for floating elements (e.g., Modals, Navigation bars). 
*   **Formula:** `surface_container_lowest` at 70% opacity + `backdrop-blur: 20px`.
*   **Signature Textures:** Use subtle linear gradients for CTAs, transitioning from `primary` (#00647b) to `primary_container` (#00d2ff). This provides a "glow" that flat color cannot replicate.

---

## 3. Typography: Technical Precision
We pair the geometric, technical rhythm of **Space Grotesk** with the fluid, elegant curves of **Cairo** for Arabic support.

| Level | Token | Font | Size | Weight | Use Case |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Display** | display-lg | Space Grotesk | 3.5rem | 700 | Hero Stats, Club Name |
| **Headline**| headline-md | Space Grotesk | 1.75rem | 600 | Section Headers |
| **Title**   | title-md | Inter | 1.125rem | 500 | Card Titles, Navigation |
| **Body**    | body-lg | Inter | 1rem | 400 | General Content |
| **Label**   | label-md | Space Grotesk | 0.75rem | 500 | Technical Data, Metadata |

**Editorial Note:** Use wide letter-spacing (0.05em) for labels to enhance the "Technical" feel. All currency references must be formatted as `00.00 MAD` using Space Grotesk for the numerical value.

---

## 4. Elevation & Depth
Depth is the soul of this system. We avoid the "flat-web" look through Tonal Layering.

*   **Ambient Shadows:** Floating cards use extra-diffused shadows. 
    *   *Value:* `0 20px 40px rgba(0, 0, 0, 0.04)`.
    *   *Logic:* Use a tinted shadow (matching `on_surface`) to mimic natural light rather than a generic grey drop-shadow.
*   **The Ghost Border Fallback:** If a container requires accessibility definition, use a "Ghost Border." 
    *   *Value:* `1px solid rgba(171, 173, 175, 0.2)` (using `outline_variant`). 
    *   *Strict Rule:* Never use 100% opaque borders.
*   **Tactile Feedback:** On hover, interactive elements should scale slightly (1.02x) and emit a soft glow using `primary_fixed` (#00d2ff).

---

## 5. Signature Components

### High-Tactile Buttons
*   **Primary:** Background `primary_container`, Text `on_primary_container`. 16px corner radius.
*   **Interaction:** On hover, add a `box-shadow: 0 0 15px #00d2ff`. On click, scale to `0.98`.
*   **Logic:** Buttons should feel "bouncy" and responsive.

### Floating Cards & Lists
*   **The Divider Ban:** Lists must not use horizontal lines. Use 24px vertical padding and `surface_container_low` background shifts on hover to separate items.
*   **Rounding:** All cards must use `DEFAULT` (1rem/16px) or `md` (1.5rem/24px) corner radii.

### Kinetic Inputs
*   **Style:** Minimalist. No bottom line or full box. Use `surface_container_highest` with a `md` (1.5rem) corner radius.
*   **Focus State:** Transition the background to `surface_container_lowest` and apply a `primary_container` ghost border.

### Status Indicators
*   **Success:** Emerald (text on `surface_container`).
*   **Warning:** Amber (text on `surface_container`).
*   **Danger:** Rose (text on `surface_container`).
*   **Note:** Use these for data badges only; do not let them dominate the Zen Kinetic palette.

---

## 6. Do’s and Don’ts

### Do:
*   **Do** use asymmetrical layouts for dashboard summaries (e.g., a large stat card overlapping a list).
*   **Do** use #clubLogo and #clubName as a fixed anchor in the top-left glass navigation.
*   **Do** use white space as a structural element. If in doubt, add more padding.
*   **Do** ensure all Arabic text (Cairo) has a 1.2x line-height compared to English for readability.

### Don’t:
*   **Don’t** use pure black (#000000). Use `on_background` (#2c2f31) for high-contrast text.
*   **Don’t** use 90-degree sharp corners. Everything in A.A.B.T. must feel approachable and safe.
*   **Don’t** use "Standard" Material shadows. Stick to the extra-diffused Ambient Shadow rules.
*   **Don’t** clutter the screen. If a piece of information isn't vital, hide it in a glass modal or a progressive disclosure element.

---
**System Sign-off:**
*Senior UI/UX Director*
*A.A.B.T Design Initiative*